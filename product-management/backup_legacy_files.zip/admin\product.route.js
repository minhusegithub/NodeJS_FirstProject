const express = require('express');
const multer = require("multer");

const router = express.Router();
// const storageMulter = require("../../helpers/storageMulter");



const upload = multer();

//khai bao controller
const controller = require("../../controllers/admin/product.controller");

//Validate
const validate = require("../../validates/admin/product.validate");

const uploadCloud = require("../../middlewares/admin/uploadCloud.middleware")

//goi controller
router.get('/', controller.index);

router.patch("/change-status/:status/:id" , controller.changeStatus);

router.patch("/change-multi" , controller.changeMulti);

router.delete("/delete/:id" , controller.deleteItem);

router.get("/create" , controller.create);

router.post(
    "/create",
    upload.single("thumbnail"),
    uploadCloud.upload,
    validate.createPost,
    controller.createPost
);

router.get("/edit/:id" , controller.edit);

router.patch(
    "/edit/:id" ,
    upload.single("thumbnail"),
    uploadCloud.upload,
    validate.createPost,
    controller.editPatch
);

router.get("/detail/:id" , controller.detail);


module.exports = router;


